@echo off
title Launch NASA Space Apps Presentation
echo Opening Planet X x SPHEREx Presentation Deck in Microsoft Edge...
start msedge "%~dp0presentation.html"
